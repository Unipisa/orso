#!/usr/bin/env python
import re
import json
import random
from math import *
import sys

if len(sys.argv) < 2 :
	print "Syntax: compito.py controlFile.py [first nnn]"
	exit(1)
#parse config
with open(sys.argv[1],"r") as f :
	exec(f.read())


docHeader='''\documentclass[11pt]{article}
\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage[italian]{babel}
\usepackage[]{qrcode}
\usepackage{multicol}
\usepackage{graphicx}
\pagestyle{empty}
\\textwidth  18cm
\\textheight 28cm
\\hoffset = -3cm
\\voffset = -4cm
\\parindent 0cm
\\setlength{\\unitlength}{1mm}
\\begin{document}
'''
docFooter='''
\\end{document}
'''

sheetHeader=''' 
\\ \\vskip 6pt
\\raisebox{{0pt}}[0pt][0pt]{{ \\raisebox{{-0.6cm}}{{ \\qrcode{{http://cern.ch/arizzi/correzione/?nnn={nnn}&matricola={nMatricola} }} }} \\hspace{{0.5cm}} Testo n. {nnn} \\ \\ - \\ \\ Matricola: {nMatricola} \\hspace{{0.5cm}} Cognome e Nome: \\hspace{{0.2cm}} {nome}  }}
\\vskip 6pt
'''

sheetFooter='''
\\vskip 6pt\n
FINE Testo n. {nnn}
\\pagebreak
'''


with open(inputTexFileName,"r") as f :
 inputTex=f.read()

m=re.match("(.*)END_TEXT(.*)END_DATA(.*)END_SOLUTION(.*)",inputTex,flags=re.DOTALL)
inputTexBody=m.group(1)
inputTexData=m.group(2)
inputTexSol=m.group(3)
inputTexMore=m.group(4)
nExercises=inputTexBody.count("ANSWERS")


def readStudents(filename):
     students=[]
     with open(filename,"r") as f :
	 for l in f.readlines() :
	     s=l.strip().split(",")
	     if len(s) > 1 :
		     students.append(tuple(s)) 
     return students	

def rndapprox(a,b):
   return float("%0.3g"%random.uniform(a,b))

def generateRandomAnswers(central,n,answers):
	
    res=[]
    # decide a spread for the answers
    spread=random.uniform(0.3,0.45)
    #choose a mean value for generating fake answers within the spread
    mean=random.uniform(central-central*spread,central+central*spread)
    for i in xrange(0,n) :
	   print spread,central,mean
	   val=central
	   #be sure that all answers are spaced by at least 6%
	   #print val,spread,mean,res
	   while min([abs((val-x)/(val+x)) for x in [central]+res+answers ])<0.03 : 
		 val=random.uniform(mean-mean*spread,mean+mean*spread)
	   res.append(val) 
    return res

def prettyFormat(a) :
        try :
            formattedAnswer="%0.3g"%a
            if len(formattedAnswer) >= 3 :
                 formattedAnswer=re.sub("e\+*(\-*)0*(.+)",'\\\\\\\\times 10^{\\1\\2}',formattedAnswer)
            else:
                 formattedAnswer="%0.3f"%a
        except :
                 formattedAnswer=a
	return formattedAnswer 
	
def printAnswers(answers):
      ret="\\hskip 1mm\n"
      for (i,a) in enumerate(answers) :
	      ret+='%s \\\\fbox{$%s$} \\hskip 11pt %% %s  \n '%(chr(65+i),prettyFormat(a),a)
      ret+='\\\\\\\\'
      return ret	 

def generateOne() :
    loc={"SOLUTION":{},"WRONG":{}} 
    for line in inputTexData.split('\n') :
	try :
		exec(line,globals(),loc)
	except :
		print "Warning: cannot parse",line, sys.exc_info()

    for line in inputTexSol.split('\n') :
	try :
		exec(line,globals(),loc)
	except :
		print "Warning: cannot parse",line, sys.exc_info()
    return loc

students=readStudents(inputStudentList)
#print students
#outputfile
outreadable=open("out.log","w")
outf=open(generatedTexFileName,"w")
#map with all generated information
outdata={}
offset=1
if len(sys.argv) > 2 :
	offset=int(sys.argv[2])

random.seed(123)

outf.write(docHeader)
for (n,(nome,nMatricola)) in enumerate(students):
	nnn="%03d"%(n+offset)
	outf.write(sheetHeader.format(nnn=nnn,nMatricola=nMatricola,nome=nome))
	outdata[nnn]={"nMatricola":nMatricola,"nome":nome}
	res=generateOne()
	keystring=""
	thisText=""+inputTexBody
	for r in res :
	  #rint r,res[r]
	  if r != "SOLUTION" and r!= "WRONG" :
             thisText=re.sub("@%s@"%r,"$"+prettyFormat(res[r])+"$",thisText)
	for i in xrange(1,nExercises+1) :
		   #print i 
		   thisData={}
		   correctAnswer=res["SOLUTION"][i]	
		   thisData["correct"]=correctAnswer
		   answers=[]
		   #read possible wrong answers from tex file
		   if i in res["WRONG"] :
			   answers.extend(list(res["WRONG"][i]))

		   #generate missing ones
	           toGenerate=nOptions - len(answers) - 1 - len(additionalOptions)
		   answers.extend(generateRandomAnswers(correctAnswer, toGenerate, answers ))

		   #append the right one
		   answers.append(correctAnswer)
		
		   #shuffle
		   random.shuffle(answers)
		   thisData["all"]=answers

		   #additional options
		   answers.extend(additionalOptions)
		   texANSWER=printAnswers(answers)
		   good=answers.index(correctAnswer)
		   thisText=re.sub("ANSWERS",texANSWER,thisText,1)
	  	   keystring+=chr(65+good)
		   thisData["goodLetter"]=chr(65+good)
		   thisData["goodPosition"]=good
		   if i in res["WRONG"] :
 		   	for j,w in  enumerate(res["WRONG"][i]) :
				thisData["wrongPosition%d"%j]=answers.index(w)
	  	   outdata[nnn][i]=thisData
        outdata[nnn]["keystring"]=keystring
	outreadable.write("%s,%s,%s\n"%(nnn,nMatricola,keystring))
        outf.write(thisText)
	outf.write(sheetFooter.format(nnn=nnn))

outf.write(docFooter)
outf.close()

outdataf=open(generatedDataFileName,"w")
outdataf.write(json.dumps(outdata))
import os
os.system("pdflatex %s "%(generatedTexFileName))
