#!/usr/bin/env python
import re
import json
import random
from math import *
import sys
import numpy as np


def goodBadUnk(s):
    ngood=sum(1 for x in s if x==correctScore)
    nbad=sum(1 for x in s if x==wrongScore)
    nun=sum(1 for x in s if x==unansweredScore)
    return ngood,nbad,nun
 
def writeStats(results): 
    f=open(correctionStatsFileName,"w")
    nTests=len(results[results.keys()[0]]["list"])
    f.write("N test \t good \t unanswered \t bad\n")
    fractions=[]
    for e in xrange(0,nTests) :
	s= [x["list"][e] for y,x in results.iteritems()]
        ngood,nbad,nun = goodBadUnk(s)
	tot=len(s)
	fractions.append(1.*ngood/tot)
	f.write("Ex %d \t %3.1f%% \t\t %3.1f%% \t\t %3.1f%%\n"%(e+1,100.*ngood/tot,100.*nun/tot,100.*nbad/tot))
    print fractions
    f.write("\nHARDNESS\n")
    for i in xrange(0,100,20) :
	ii=i+20
	p=sum(1 for x in fractions if x > i/100. and x<=ii/100.)
	f.write("exact answers in %s%%-%s%% \t%s\n"%(i,ii,p))


    f.write("\nSCORES PERCENTILE\n")
    scores= np.array([x["score"] for y,x in results.iteritems()])
    f.write("Avg %s\n"%np.mean(scores))
    for i in xrange(0,100,10) :
	p=np.percentile(scores,i)
        n=len([x for x in scores if  x >= p])	
	f.write("percentile %s %s %s\n"%(i,p,n))

    f.write("\nSCORES DISTRIBUTION\n")
    xx=[x["score"] for y,x in results.iteritems()]
    f.write("Avg %s\n"%np.mean(scores))
    for i in xrange(0,nTests+1) :
        n=len([x for x in xx if  x >= i])	
	f.write("score %s %s %s\n"%(i,100.*n/len(xx),n))


    f.close()

def writeBoard(results,alldata):
    f=open(correctionBoardFileName,"w")
    for nnn in results :
	f.write("%s\t\t , %s \t\t , %s \t\t, %s\n"%( alldata[nnn]["nMatricola"],nnn,alldata[nnn]["keystring"],results[nnn]["score"]))
    f.close()

def writeGroupedMarks(results,alldata):
    f=open(correctionMarksFileName,"w")
    for nnn in results :
        start=0
	groups="%s,%s,%s,\t"%(goodBadUnk(results[nnn]["list"]))
        for stop in groupBoundaries+[len(results[nnn]["list"])] :
		sub=results[nnn]["list"][start:stop]
		start=stop
		groups+="%s,%s,%s,\t"%(goodBadUnk(sub))
#	scoreWithBoundary() 
        f.write("%s\t\t , %s \t\t , %s \t\t, %s,\t\t %s\n"%( alldata[nnn]["nMatricola"],nnn,alldata[nnn]["keystring"],results[nnn]["score"],groups))
    f.close()


if len(sys.argv) < 2 :
        print "Syntax: correzion.py controlFile.py"
        exit(1)
#parse config
with open(sys.argv[1],"r") as f :
        exec(f.read())

alldata=json.load(open(generatedDataFileName))
allAnswers={}
error=False
with open(studentsAnswers,"r") as f:
    for line in f :
	ans=answerParser(line.strip())
	if ans["nMatricola"] is not None :
		pass #TODO: insert here the check against expected nMatricola
	if ans["nnn"] in allAnswers and ans["answers"] != allAnswers[ans["nnn"]]["answers"]:	
		   	print "Error: received two different sets of answers for number ",  ans["nnn"]
			print "    ",ans["answers"]
			print "    ",allAnswers[ans["nnn"]]["answers"]
			error=True
	allAnswers[ans["nnn"]]=ans

if error :
	print "Cannot continue because of above errors, please correct them first"
	exit(1)

missingAnswers=[]
results={}
#print allAnswers
for nnn in sorted(alldata) :
	if nnn not in allAnswers :
		missingAnswers.append(nnn)
	else :
		score=0
		scoreList=[]
		results[nnn]={}
		correct=alldata[nnn]["keystring"].strip().upper()
		given=allAnswers[nnn]["answers"].strip().upper()
		if len(correct) != len(given) :
			print "Warning: for number ",nnn," the answer length is mismatching"
			print "     ",correct
			print "     ",given
		for (c,g,f) in zip(correct,given,forcedAnswer.ljust(len(correct),'.')) :
			#apply mask
			if f!='.':
			   c=f
			if g in unansweredValues :
				score+=unansweredScore
				scoreList.append(unansweredScore)
			elif g==c :
				score+=correctScore
				scoreList.append(correctScore)
			else :
				score+=wrongScore
				scoreList.append(wrongScore)
		results[nnn]["list"]=scoreList	
		results[nnn]["score"]=score

print "Missing answers: ", len(missingAnswers)
fm = open(correctionMissingFileName,"w")
for m in missingAnswers :
	fm.write("%s\n"%m)
print "Given answers: ", len(results)

writeStats(results)
writeGroupedMarks(results,alldata)
writeBoard(results,alldata)
