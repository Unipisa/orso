inputTexFileName="compito.tex"
inputStudentList="elenco_alunni.txt"
#total number of answers, including the right one and the additional
nOptions=6  
additionalOptions=["Altro"]
#generatedDataFileName="compito.json"
generatedDataFileName="test2.json"
generatedTexFileName="compito_generato.tex"


####### for correction ##############################
studentsAnswers="risposte.txt"

#with student number
#answersParser=lambda line : {"nnn":re.match("PUNZI +(.*) +(.*) +(.*)",line).group(1),"answers":re.match("PUNZI +(.*) +(.*) +(.*)",line).group(3),"nMatricola":re.match("PUNZI +(.*) +(.*) +(.*)",line).group(2) }

#without student number
answerParser=lambda line : {"nnn":re.match("PUNZI +([0-9]+) +(.+)",line).group(1),"answers":re.match("PUNZI +([0-9]+) +(.+)",line).group(2),"nMatricola":None }


forcedAnswer=".....F...."

unansweredValues=[".","Z"]
unansweredScore=0
wrongScore=-0.5
correctScore=1.

#boundaries to group scores (using < and counting from "0")
groupBoundaries=[2,4,6]

correctionMissingFileName="corr.miss"
correctionStatsFileName="corr.sta"
correctionMarksFileName="corr.mrk"
correctionBoardFileName="corr.brd"
